import os
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util import Padding
import pandas as pd
import yaml
import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.DEBUG, datefmt='%d-%b-%y %H:%M:%S')


class Encrypt(object):

    def __init__(self):
        self.MULTIPLE_OF_SIXTEEN = 16

    def generate_secret(self,output_file):
        """
        python 3 is nice with from binary .hex() and from hex to bytes .fromhex()
        """
        secret = os.urandom(self.MULTIPLE_OF_SIXTEEN).hex()
        # output_file = path+"secret_hex_" + datetime.now().strftime('%Y-%m-%d-%H-%M-%S') + '.secret'
        with open(output_file, "w") as file:
            # We don't need write in binary mode anymore
            file.write(secret)
            
        IV = AES.new(secret.encode(),AES.MODE_CBC).iv
        
        iv_file_name_str = output_file.replace('.secret','.bin')
        
        f = open(iv_file_name_str, "wb")
        f.write(IV)
        f.close()

        return secret,IV,output_file

    @staticmethod
    def get_secret(secret_file_name_str):
        """
        We expect a hex encoded secret
        """
        with open(secret_file_name_str, "r") as file:
            # we don't need to read in binary mode here
            secret = file.read()
        iv_file_name_str = secret_file_name_str.replace('.secret','.bin')
        f = open(iv_file_name_str, "rb")
        IV = f.read()
        f.close()
        return secret,IV

    @staticmethod
    def get_closest_larger_multiple_of_sixteen(n):
        remainder = n % 16
        if remainder == 0:
            return n
        else:
            return n + (16 - remainder)

    def encrypt_df_columns(self, df: pd.DataFrame, list_of_columns:list, secret_file_name_str=None):
        df2 = df.copy()
        if secret_file_name_str == None:
            secret,IV,secret_file_name_str = self.generate_secret()
        else:
            secret,IV = self.get_secret(secret_file_name_str)
           
        for col in list_of_columns:
            try:
                # make the encryption object
                #obj = AES.new(secret_pad,AES.MODE_SIV)
                df2[col] = df2[col].apply(
                    lambda x : AES.new(secret.encode(),AES.MODE_CBC,iv=IV).encrypt( Padding.pad(str(x).encode(),16) )
                                            )
                # above tries to do "smart padding" by expanding to a multiple of 16 only if needed
            except:
                logging.error(f"error: {col}")
                pass

        return df2

    def decrypt_df_columns(self,df:pd.DataFrame, list_of_columns:list, list_of_dtypes:list,secret_file_name_str:str):
        df2 = df.copy()
        if secret_file_name_str == None:
            raise ValueError('Aborting -- we need a secret file to continue decrypt')
        else:
            secret,IV = self.get_secret(secret_file_name_str)

        for col,typ in zip(list_of_columns,list_of_dtypes):
            try:
                df2[col] = df2[col].apply(lambda x: Padding.unpad(AES.new(secret.encode()
                                                                          ,AES.MODE_CBC,iv=IV).decrypt(x),16).decode())
                df2[col] = df2[col].astype(typ)
            except:
                logging.error(f'error: {col}')
                pass
        return df2

    def hash_df_columns(self,df:pd.DataFrame, list_of_columns:list):
        for col in list_of_columns:
            df[col] = df[col].apply(lambda x: hash(str(x)))
        return df


def _read_yaml(config_path):
    with open(config_path, "r") as f:
        logging.info(f"Config file read in succesfully.")
        return yaml.safe_load(f)


def set_config(config_path):
    config = _read_yaml(config_path)

    filename = config['mis_query']['raw_extract_filename']
    cols = config['anonymisation']['anon_cols']
    secret_filepath = config['anonymisation']['secret_filepath']
    process = config['anonymisation']['process']

    if process == 'encrypt':
        from_path = config['anonymisation']['anon_from']
        to_path = config['anonymisation']['anon_to']
    elif process == 'decrypt':
        from_path = config['anonymisation']['deanon_from']
        to_path = config['anonymisation']['deanon_to']
    else:
        logging.error(f'Process not specified in the config.yml correctly.')
    
    parquet_path_from = f'{from_path}{filename}'
    parquet_path_to = f'{to_path}{filename}'
    
    logging.debug(f'Anonymisation Config loaded successfully.')
    logging.debug(f'{parquet_path_from}')
    logging.debug(f'{parquet_path_to}')
    logging.debug(f'{cols}')
    logging.debug(f'{secret_filepath}')

    return parquet_path_from, parquet_path_to, cols, secret_filepath, process


def load_dataframe(parquet_path_from):
    df = pd.read_parquet(parquet_path_from)
    logging.debug('Dataframe loaded successfully')
    return df


def encrypt_cols(encrypt, df, cols, secret_filepath):
    logging.debug('Encrypting file.')
    df_encrypted = encrypt.encrypt_df_columns(df,cols,secret_filepath)
    logging.debug('Encrypted dataframe created.')
    return df_encrypted


def decrypt_cols(encrypt, df, cols, col_dtypes, secret_filepath):
    logging.debug('Decrypting file.') 
    df_decrypted = encrypt.decrypt_df_columns(df,cols, col_dtypes, secret_filepath)
    logging.debug('Decrypted dataframe created.')
    return df_decrypted


def write_df_to_file(df_encrypted, filepath):
    df_encrypted.to_parquet(filepath,index=False)
    logging.info('Encrypted dataframe written to file successfully.')


def main():
    config_path = '../conf/config.yml'
    parquet_path_from, parquet_path_to, cols, secret_filepath, process = set_config(config_path)
    encrypt = Encrypt()

    # TODO: Decouple Encrypt code into another script.
    # encrypt.generate_secret(secret_filepath)

    encrypt.get_secret(secret_filepath)
    df = load_dataframe(parquet_path_from)
    if process == 'encrypt':
        df_crypted = encrypt_cols(encrypt, df, cols, secret_filepath)
        logging.debug(f'Created encrypted dataframe.')
    if process == 'decrypt':
        col_dtypes = ['str', 'str', 'str'] # TODO: Take this into the yaml! 
        df_crypted = decrypt_cols(encrypt, df, cols, col_dtypes, secret_filepath)
        logging.debug(f'Created decrypted dataframe.')

    write_df_to_file(df_crypted, parquet_path_to)
    logging.info('Data Anon Process completed.')


if __name__ == '__main__':
    main()