import pysftp
import yaml
import pandas as pd
import logging

logging.basicConfig(format='%(asctime)s - %(levelname)s - %(message)s', level=logging.DEBUG, datefmt='%d-%b-%y %H:%M:%S')

def _read_yaml(config_path):
    with open(config_path, "r") as f:
        logging.info(f"Config file read in succesfully.")
        return yaml.safe_load(f)


def set_ip(host_ip_1, host_ip_2):
    cnopts = pysftp.CnOpts(knownhosts=host_ip_1)
    cnopts.hostkeys = None
    return cnopts


def create_connection(host_ip_1, username, cnopts, pvt_key, pvt_key_pass):
    #Connect
    srv = pysftp.Connection(host=host_ip_1, username=username,cnopts=cnopts, private_key=pvt_key, private_key_pass=pvt_key_pass)
    return srv


def load_aws(srv, path_from, path_to, process):
    if process == 'upload':
        #Upload a file
        logging.debug('Uploading to AWS.')
        srv.put(path_from,path_to)
        logging.info(f"File uploaded from {path_from} to {path_to}")
    elif process == 'download':
        # Download a file
        logging.debug(f'Downloading from AWS.')
        srv.get(path_from,path_to)
        logging.info(f"File downloaded from {path_from} to {path_to}")  


def set_sftp_connection_credentials(credentials_path):
    credentials = _read_yaml(credentials_path)
    username = credentials['aws_sftp']['username']
    pvt_key_pass = credentials['aws_sftp']['pvt_key_pass']
    pvt_key = credentials['aws_sftp']['pvt_key']
    logging.debug(f'SFTP Connection Config loaded successfully.')
    return username, pvt_key_pass, pvt_key


def set_sftp_connection_config(config_path):
    config = _read_yaml(config_path)
    host_ip_1 = config['aws_sftp']['host_ip_1']
    host_ip_2 = config['aws_sftp']['host_ip_2']
    process = config['aws_sftp']['process']
    raw_extract_filename = config['mis_query']['raw_extract_filename']

    if process == 'upload':
        from_path = config['aws_sftp']['upload_from']
        to_path = config['aws_sftp']['upload_to']
    elif process == 'download':
        from_path = config['aws_sftp']['download_from']
        to_path = config['aws_sftp']['download_to']
    else:
        logging.error(f'Process not specified in the config.yml correctly.')

    parquet_path_from = f'{from_path}{raw_extract_filename}'
    parquet_path_to = f'{to_path}{raw_extract_filename}'

    logging.debug(f'SFTP Config loaded successfully.')
    return host_ip_1, host_ip_2, parquet_path_from, parquet_path_to, process


def main():
    config_path = '../conf/config.yml'
    credentials_path = "../conf/credentials.yml"

    host_ip_1, host_ip_2, parquet_path_from, parquet_path_to, process = set_sftp_connection_config(config_path)
    username, pvt_key_pass, pvt_key = set_sftp_connection_credentials(credentials_path)
    
    cnopts = set_ip(host_ip_1, host_ip_2)
    srv = srv = pysftp.Connection(host='10.2.249.38', username="data_loader",cnopts=cnopts, private_key="/home/fohls002/private_key2.key", private_key_pass="bigdata")
    load_aws(srv, parquet_path_from, parquet_path_to, process)
    logging.info('AWS data load process complete.')


if __name__ == '__main__':
    main()


