# Introduction
This repo has a skeleton template to copy data to and from MIS in market to AWS S3 via a SFTP server connection.

## Pre-Requisites

1. Access to market server. This code is designed to be run on the server. 
2. Access to AWS
3. Access to MIS database. User credentials are required to access the DB to extract data.
4. Unique Packages required:
    - pysftp
    - cx_Oracle
    - boto3
    - pyarrow

# Directory Structure
- conf -> stores config.yml and credentials.yml here. 
- data
    - 01_sql -> SQL files that will execute on MIS stored as .txt
    - 02_raw_extract -> Location where data will land from MIS
    - 03_anonymised -> Location where anonymised data is stored
    - 04_to_upload 
    - 05_uploaded
    - 06_downloaded -> Location where downloaded files from AWS will be stored.
    - 07_deanonymised -> Location where de-anonymised data is stored
    - secrets -> Contains the secret, binary and pem files
- notebooks
- src -> python scripts

# config.yml
The structure of the config file is as follows:
```
mis_query:
    sql_query_path: '../data/01_sql/accounts_entry_01102021_07102021.txt'
    raw_extract_path: '../data/02_raw_extract/' 
    raw_extract_filename: '01102021_07102021.parquet'

anonymisation:
    process: 'encrypt' # Enter 'encrypt' or 'decrypt'
    secret_filepath: '../data/secrets/secret_hex_2021-10-28-20-37-37_drc.secret'
    anon_from: '../data/02_raw_extract/' 
    anon_to: '../data/03_anonymised/FCT_MMAE_MM_ACCOUNT_ENTRY/'
    deanon_from: '../data/06_downloaded/'
    deanon_to: '../07_deanonymised/'
    anon_cols: ['MMAE_IDENTITY_MNEMONIC','MMAE_TRANS_IDENTITY_MNEMONIC','MMAE_DETAILS'] # These are the columns we are anonymising.
    anon_cols_dtypes: ['str', 'str', 'str'] # -> These are the data types for the columns.

aws_sftp:
    process: 'upload' # Enter 'upload' or 'dowload'
    host_ip_1: "10.2.249.147"
    host_ip_2: "10.2.249.169"
    upload_from: '../data/03_anonymised/FCT_MMAE_MM_ACCOUNT_ENTRY/' #'../data/02_raw_extract/'
    upload_to: 'FCT_MMAE_MM_ACCOUNT_ENTRY/' #'REFERENCE_TABLES/'
    download_from: 'FCT_MMAE_MM_ACCOUNT_ENTRY/'
    download_to: '../data/06_downloaded/'
```
This file must be edited for every upload to ensure the correct filename and filepaths are being used.

# credentials.yml
The structure of the config file is as follows:
```
mis_db:
    username: xxx
    password: xxx
    hostname: 10.200.200.54
    port: 1521
aws_sftp:
    username: "mpesa-sftp"
    pvt_key_pass: "mpesa"
    pvt_key: "../data/secrets/drc_pvt_key.pem"
```
Once you have updated this file with your user credentials for the DB and pointed to your private key for SFTP connection, 
no further editing will be required. 

## Upload example

Note: All logging (set to debug mode) is done to console. 

1. Create relevant sql code and place it in a file, e.g. `accounts_entry_01092021_02092021.txt`
2. Update config.yml:
    - sql_query_path: '../data/01_sql/accounts_entry_01102021_07102021.txt'
    - raw_extract_filename: '01102021_07102021.parquet'
    - anonymisation:
        process: 'encrypt'
    - aws_sftp:
        process: 'upload'
    - upload_from: '../data/03_anonymised/FCT_MMAE_MM_ACCOUNT_ENTRY/' 
    - upload_to: 'FCT_MMAE_MM_ACCOUNT_ENTRY/' # -> The SFTP server is already mapped to the S3 location: s3://mpa-bdl-raw/drc/

3. Be in the `src` directory of the project, ensure your conda/venv is activated, run:
```
python 01_extract_mis_data.py
```
Monitor logs to wait for completion.
4. Be in the `src` directory of the project, ensure your conda/venv is activated, run:
```
python 02_anonymise_data.py
```
Monitor logs to wait for completion.
5. Be in the `src` directory of the project, ensure your conda/venv is activated, run:
```
python 03_aws_data_load.py
```
Monitor logs to wait for completion.
6. Verify on S3, e.g -> s3://mpa-bdl-raw/drc/FCT_MMAE_MM_ACCOUNT_ENTRY/

## Download example

Note: All logging (set to debug mode) is done to console. 

1. Update config.yml:
    - anonymisation:
        process: 'decrypt'
    - aws_sftp:
        process: 'download'
    - download_from: 'FCT_MMAE_MM_ACCOUNT_ENTRY/' # -> change to relevant dir on SFTP server

2. Be in the `src` directory of the project, ensure your conda/venv is activated, run:
```
python 03_aws_data_load.py
```
Monitor logs to wait for completion.
3. Be in the `src` directory of the project, ensure your conda/venv is activated, run:
```
python 02_anonymise_data.py
```
Monitor logs to wait for completion.
4. Verify downloaded file in `data/07_deanonymised/`