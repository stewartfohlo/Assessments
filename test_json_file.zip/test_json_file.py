import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ["JOB_NAME"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Script generated for node S3 bucket
S3bucket_node1 = glueContext.create_dynamic_frame.from_options(
    format_options={"multiline": False},
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://drcgsmlandingraw/data_eng_scripts/delta_files_part/"],
        "recurse": True,
    },
    transformation_ctx="S3bucket_node1",
)

# Script generated for node Apply Mapping
ApplyMapping_node1643613917693 = ApplyMapping.apply(
    frame=S3bucket_node1,
    mappings=[
        ("schema.name", "string", "schema.name", "string"),
        ("schema.optional", "boolean", "schema.optional", "boolean"),
        ("schema.type", "string", "schema.type", "string"),
        ("schema.fields", "array", "schema.fields", "array"),
        ("payload.op", "string", "payload.op", "string"),
        ("payload.before", "null", "payload.before", "null"),
        (
            "payload.after.legal_entity_id",
            "null",
            "payload.after.legal_entity_id",
            "null",
        ),
        (
            "payload.after.country_of_residence",
            "null",
            "payload.after.country_of_residence",
            "null",
        ),
        ("payload.after.birth_date", "null", "payload.after.birth_date", "null"),
        ("payload.after.wallet_email", "null", "payload.after.wallet_email", "null"),
        ("payload.after.created_at", "string", "payload.after.created_at", "string"),
        ("payload.after.type", "string", "payload.after.type", "string"),
        ("payload.after.given_names", "null", "payload.after.given_names", "null"),
        ("payload.after.updated_at", "string", "payload.after.updated_at", "string"),
        ("payload.after.id", "string", "payload.after.id", "string"),
        ("payload.after.pesel", "null", "payload.after.pesel", "null"),
        ("payload.after.status_reason", "null", "payload.after.status_reason", "null"),
        ("payload.after.first_name", "string", "payload.after.first_name", "string"),
        ("payload.after.email", "null", "payload.after.email", "null"),
        (
            "payload.after.preferred_language",
            "string",
            "payload.after.preferred_language",
            "string",
        ),
        ("payload.after.tenant", "string", "payload.after.tenant", "string"),
        ("payload.after.wallet_phone", "null", "payload.after.wallet_phone", "null"),
        (
            "payload.after.is_identified",
            "boolean",
            "payload.after.is_identified",
            "boolean",
        ),
        ("payload.after.birth_name", "null", "payload.after.birth_name", "null"),
        ("payload.after.citizenship", "null", "payload.after.citizenship", "null"),
        ("payload.after.sex", "null", "payload.after.sex", "null"),
        ("payload.after.last_name", "string", "payload.after.last_name", "string"),
        ("payload.after.birth_place", "null", "payload.after.birth_place", "null"),
        ("payload.after.elid_phone", "null", "payload.after.elid_phone", "null"),
        ("payload.after.middle_name", "null", "payload.after.middle_name", "null"),
        (
            "payload.after.ident_provider",
            "null",
            "payload.after.ident_provider",
            "null",
        ),
        ("payload.after.nationality", "null", "payload.after.nationality", "null"),
        ("payload.after.user_id", "string", "payload.after.user_id", "string"),
        ("payload.after.elid_identity", "null", "payload.after.elid_identity", "null"),
        ("payload.after.updated_by", "null", "payload.after.updated_by", "null"),
        (
            "payload.after.updated_by_db_user",
            "string",
            "payload.after.updated_by_db_user",
            "string",
        ),
        ("payload.after.status", "string", "payload.after.status", "string"),
        ("payload.after.number", "string", "payload.after.number", "string"),
        (
            "payload.after.is_inactive",
            "boolean",
            "payload.after.is_inactive",
            "boolean",
        ),
        ("payload.after.client_id", "string", "payload.after.client_id", "string"),
        ("payload.source.schema", "string", "payload.source.schema", "string"),
        ("payload.source.sequence", "string", "payload.source.sequence", "string"),
        ("payload.source.xmin", "null", "payload.source.xmin", "null"),
        ("payload.source.connector", "string", "payload.source.connector", "string"),
        ("payload.source.lsn", "long", "payload.source.lsn", "long"),
        ("payload.source.name", "string", "payload.source.name", "string"),
        ("payload.source.txId", "int", "payload.source.txId", "int"),
        ("payload.source.version", "string", "payload.source.version", "string"),
        ("payload.source.ts_ms", "long", "payload.source.ts_ms", "long"),
        ("payload.source.snapshot", "string", "payload.source.snapshot", "string"),
        ("payload.source.db", "string", "payload.source.db", "string"),
        ("payload.source.table", "string", "payload.source.table", "string"),
        ("payload.ts_ms", "long", "payload.ts_ms", "long"),
        ("payload.transaction", "null", "payload.transaction", "null"),
    ],
    transformation_ctx="ApplyMapping_node1643613917693",
)

# Script generated for node Amazon S3
AmazonS3_node1643613943169 = glueContext.write_dynamic_frame.from_options(
    frame=ApplyMapping_node1643613917693,
    connection_type="s3",
    format="glueparquet",
    connection_options={
        "path": "s3://drcgsmlandingraw/data_eng_scripts/parquet_out/",
        "partitionKeys": [],
    },
    format_options={"compression": "snappy"},
    transformation_ctx="AmazonS3_node1643613943169",
)

job.commit()
